<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Document</title>
</head>
<body>
<?php 
        include 'header.php';
?>

<h2 id="pavad">Krevetes sonines patale</h2><br>
<img id="img" src="https://www.receptai.lt/uploads/modules/recipes/fullsize/10197.jpg" alt = "Krevetes sonines patale" width = "200" height = "170">

<div class="grid-container">
<div class="grid-item" id="info">
<p><b>Paruosimo laikas:</b> apie 20 min.<br>
<b>Porciju skaicius:</b> 5</p>
</div>

<div class="grid-item" id="visiingr">
<ol><b>Ingredientai:</b>
  <li><em><text>Krevetes</text></em>, 20 vienetu</li>
  <li><em><text>Saltai rukyte sonine</text></em>, 10 riekiu</li>
  <li><em><text>Kotanyi zuvies kepsniu prieskoniai</text></em>, 1 ziupsnelis</li>
</ol>
  </div>

<div class="grid-item" id="gam">
  <ul><b>Gaminimo eiga:</b>
  <li>Šoninės juosteles perpjauti perpus, įtrinti prieskoniais.</li>
  <li>Kiekviena juostelės puse apvynioti po krevetę.</li>
  <li>Kepti grilyje iš abiejų pusių, kol šoninė pasidarys traški.</li>
  <li>Skanauti su klevų sirupu.</li>
</ul><br>
  </div>
</div>
  <hr>
  
<a href="receptai3.php">Ziureti praejusi recepta</a><br>
<a href="index.php">Grizti i pradini puslapi</a>


<?php 
        include 'footer.php';
?>


</body>
</html>