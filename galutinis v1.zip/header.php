
<header>
    <img id="logo" src="https://cdn.pixabay.com/photo/2015/08/19/02/27/restaurant-895428_1280.png" alt="logo">
    <h1 id="pav">Mūsų receptai </h1> 
</header>

