<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Document</title>
</head>
<body>
<?php 
        include 'header.php';
?>

<h2>Kreveciu blyneliai</h2><br>
<img src="https://www.receptai.lt/uploads/modules/recipes/thumb380x250/10229.jpg" alt ="Kreveciu blyneliai" width ="200", height ="150">
<p><b>Paruosimo laikas:</b> apie 20min.<br>
<b>Porciju skaicius:</b> 2</p>

<ol><b>Ingredientai:</b>
  <li><em><text style="color:red;">Krevetes</text></em>, 200 gramu</li>
  <li><em><text style="color:red;">Miltai</text></em>, 2 valgomieji saukstai</li>
  <li><em><text style="color:red;">Aitriosios paprikos milteliai</text></em>, 1 ziupsnelis</li>
</ol>



<ul><b>Gaminimo eiga:</b>
  <li>Krevetes sutrinti kombainu, sumaišyti su miltais ir čili.</li>
  <li>Blynelius kepti aliejuje.</li>
  <li>Sudėti ant ranksluostinio popieriaus, kad nuvarvėtų riebalai.</li>
  <li>PaPatiekti su žalumynais ir citrina</li>
</ul><hr><br>
  
<a href="receptai2.php">Sekantis receptas</a><br>
<a href="index.php">Grizti i pradini puslapi</a>

<?php 
        include 'footer.php';
?>


</body>
</html>