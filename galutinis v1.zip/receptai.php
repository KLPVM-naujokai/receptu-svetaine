<table class="receptukai">
    <tr>
        <td >
            <a href="receptai1.php">
                <img src="https://www.receptai.lt/uploads/modules/recipes/thumb380x250/10229.jpg" alt ="Kreveciu blyneliai">
                <h2>Kreveciu blyneliai</h2><br>
            </a>
        </td>

        <td>
            <a href="receptai2.php">
                <img src ="https://www.receptai.lt/uploads/modules/recipes/thumb380x250/10173.jpg" alt ="Astrios krevetes grilyje">
                <h2>Astrios krevetes grilyje</h2><br>
            </a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="receptai3.php">
                <img src ="https://www.receptai.lt/uploads/modules/recipes/thumb380x250/10164.jpg" alt = "Keptos krevetes">
                <h2>Keptos krevetes</h2><br>
            </a>
        </td>
        <td>
            <a href="receptai4.php">
                <img src="https://www.receptai.lt/uploads/modules/recipes/fullsize/10197.jpg" alt = "Krevetes sonines patale">
                <h2>Krevetes sonines patale</h2><br>
            </a>
        </td>
    </tr>
</table>