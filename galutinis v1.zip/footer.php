<div class="footer">
  <p>2020. Visos autoriu teises saugomos. Autoriai: KLPVM-naujokai</p>
</div>

