<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Document</title>
</head>
<body>
<?php 
        include 'header.php';
?>
<h2 id="pavad">Keptos krevetes</h2><br>
<img id="img" src ="https://www.receptai.lt/uploads/modules/recipes/thumb380x250/10164.jpg" alt = "Keptos krevetes" width = "200" height = "180">

<div class="grid-container">
<div class="grid-item" id="info">
<p><b>Paruosimo laikas:</b> apie 10min.<br>
<b>Porciju skaicius:</b> 2</p>
</div>

<div class="grid-item" id="visiingr">
  <ol><b>Ingredientai:</b>
  <li><em><text>Krevetes</text></em>, 300 gramu</li>
  <li><em><text>Baltas vynas</text></em>, 100 mililitru</li>
  <li><em><text>Pipirai</text></em>, 1 ziupsnelis</li>
</ol>
  </div>

<div class="grid-item" id="gam">
  <ul><b>Gaminimo eiga:</b>
  <li>Krevetes 5 minutes pamirkyti vyne. Nuvarvinti.</li>
  <li>Sumauti ant iešmelių, pagardinti pipirais.</li>
  <li>Kepti ant įkaitusių anglių, po 3 minutes kiekvieną pusę.</li>
  </ul><br>
  </div>
</div>
  <hr>
  
<a href="receptai2.php">Ziureti praejusi recepta</a><br>
<a href="receptai4.php">Sekantis receptas</a><br>
<a href="index.php">Grizti i pradini puslapi</a>


<?php 
        include 'footer.php';
?>


</body>
</html>