<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Document</title>
</head>
<body>
<?php 
        include 'header.php';
?>

<h2 id="pavad">Astrios krevetes grilyje</h2><br>
<img id="img" src ="https://www.receptai.lt/uploads/modules/recipes/thumb380x250/10173.jpg" alt ="Astrios krevetes grilyje" width ="200" height = "170">

<div class="grid-container">
<div class="grid-item" id="info">
<p><b>Paruosimo laikas:</b> apie 5min.<br>
<b>Porciju skaicius:</b> 4</p>
</div>

<div class="grid-item" id="visiingr">
  <ol><b>Ingredientai:</b>
  <li><em><text>Krevetes</text></em>, 400 gramu</li>
  <li><em><text>Tabasko padazas</text></em>, 5 valgomieji saukstai</li>
  <li><em><text>Aitrioji paprika</text></em>, 0.5 arbatinio saukstelio</li>
  <li><em><text>Zalioji citrina</text></em>, 1 vienetas</li>
</ol>
 </div>

<div class="grid-item" id="gam">
  <ul><b>Gaminimo eiga:</b>
  <li>Jei krevetės šaldytos, atitirpinti. Nusausinti.</li>
  <li>Krevetes apiberti čili, apšlakstyti padažu.</li>
  <li>Kepti grilyje po 2 minutes iš kiekvienos pusės.</li>
  <li>Patiekti su žaliosios citrinos skiltele</li>
</ul><br>
</div>
</div>
  <hr>
<a href="receptai1.php">Ziureti praejusi recepta</a><br>
<a href="receptai3.php">Sekantis receptas</a><br>
<a href="index.php">Grizti i pradini puslapi</a>

<?php 
        include 'footer.php';
?>


</body>
</html>